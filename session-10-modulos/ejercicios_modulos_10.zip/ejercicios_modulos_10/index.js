import * as Operaciones from "./modulos/controller.js";
import chalk from "chalk";
const Suma = Operaciones.suma(4,5)

const Mult = Operaciones.multuplica(1,2)

console.log(chalk.green(Suma));
console.log(chalk.green(Mult));






