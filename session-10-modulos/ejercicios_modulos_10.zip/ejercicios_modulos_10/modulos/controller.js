export function suma(a,b){
        return a + b;
}

export function multuplica(a,b){
    return a*b;
}
